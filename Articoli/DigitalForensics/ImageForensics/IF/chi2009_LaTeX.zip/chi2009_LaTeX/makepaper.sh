#! /bin/bash
pdflatex sample
bibtex sample
pdflatex sample
pdflatex sample
